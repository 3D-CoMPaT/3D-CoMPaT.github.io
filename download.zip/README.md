## Folder structure

Models in the dataset are indexed by an id, a 36 characters string of the form:

`deadb33f-dead-b33f-b33f-b33ff0000000`

Styles for each dataset are indicated following an underscore:

`deadb33f-dead-b33f-b33f-b33ff0000000_1337`

Where "`1337`" is the style id.

Finally, for rendered views, the identifiers for each canonical/random view corresponding to a style are indicated using an additional underscore:

`deadb33f-dead-b33f-b33f-b33ff0000000_1337_0`

Where `0` is the first of the four views corresponding to the `1337` style.

</br>

## Download

To download the dataset, please run the "download.py" script:

    usage: download.py [-h] --outdir OUTDIR --data-type {canonical_seg,canonical_views,random_views,rendered_models}

    optional arguments:
      -h, --help            show this help message and exit
      --outdir OUTDIR       Output folder in which the zips should be downloaded
      --data-type {canonical_seg,canonical_views,random_views,rendered_models}
                            Data type to download. One of "canonical_seg" for canonical views segmentations masks,
                            "canonical_views" or "random_views" for canonical/random views, "rendered_models" for rendered 3D models.


The dataset metadata is provided in the `metadata` folder. The `label.json` file provides labels for all models in the dataset in numerical form. The `part_material_map.json` file provides a list of parts and their associated material category, for each model, which is valid across all of its styles.
