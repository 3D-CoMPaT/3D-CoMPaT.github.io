# 3D CoMPaT: Download instructions

We provide here detailed instructions on how to download the 3DCoMPaT dataset.

## Downloading

### A. Using our download script

To download the dataset automatically, please run the "download.py" script using the following parameters:

```
usage: download.py [-h] --outdir OUTDIR --data-type {compat10,compat50,raw_models}

Download the 3DCompat dataset.

optional arguments:
  -h, --help            show this help message and exit

  --outdir OUTDIR       Output folder in which the tars should be downloaded

  --data-type {compat10,compat50,raw_models}
                        Data type to download. Use "compat10" or "compat50" to download 10 or 50 rendered compositions, or "raw_models" for untextured 3D CAD models.
```

For example, to download the CoMPaT10 benchmark in the "data" folder, run the following command:

```bash
python3 download.py --outdir data --data-type compat10
```

CoMPaT10 and CoMPaT50 images are provided in the [WebDataset](https://github.com/webdataset/) format. For more information about their structure and usage, please check out [our Notebook demo here](https://github.com/Vision-CAIR/3dcompat/blob/main/compat_api/demo_2D.ipynb).

<br/>

### B. Directly from AWS servers

To download the WDS packages directly from our AWS S3 Bucket, we provide the followign base URLs:

- For raw 3D CAD models, use:

```
https://3dcompat-dataset.s3-us-west-1.amazonaws.com/GLB/{model_id}.glb
```

Where `{model_id}` should be replaced by a model identifier. You will find model identifiers in the `models.json` file [in this folder](models.json).

To download all models packaged in a single zip (**recommended**), use the following URL:

```
https://3dcompat-dataset.s3-us-west-1.amazonaws.com/GLB/all_models.zip
```

- For CoMPaT10 and CoMPaT50 packages, use:

```
https://3dcompat-dataset.s3-us-west-1.amazonaws.com/WDS/{split}/{split}_{comp}.tar
```

Where `split` should be one of `train` or `val`, and `comp` is the identifier of the composition package to download, with two leading zeroes.

For example, to download the training data of the first 10 compositions of our dataset (corresponding to the CoMPaT10 benchmark), use:

```
https://3dcompat-dataset.s3-us-west-1.amazonaws.com/WDS/train/train_0000.tar
https://3dcompat-dataset.s3-us-west-1.amazonaws.com/WDS/train/train_0001.tar

...

https://3dcompat-dataset.s3-us-west-1.amazonaws.com/WDS/train/train_0049.tar
```

## Checksums

We provide SHA-1 checksums for every packaged TAR file in each data split, in the [checksum](./checksum/) folder.

You can re-generate the checksum for your own downloaded files using the following bash command:

```bash
cd ./train/
for f in *.tar; do sha1sum $f; done 
```

## Metadata

The dataset metadata for 3DCoMPaT is provided in the [metadata](https://github.com/Vision-CAIR/3dcompat/tree/main/metadata) folder in our repository.

For more information, please consult the `README.md` file associated.
