"""
Downloading the 3DCoMPaT dataset.
"""


import argparse
import json
import os


ROOT_BUCKET_URL = "https://3dcompat-dataset.s3-us-west-1.amazonaws.com/"

def load_json(file):
    return json.load(open(file, "r"))


def parse_args(argv):
    """
    Parsing input arguments.
    """

    # Arguments
    parser = argparse.ArgumentParser(description='Download the 3DCompat dataset.')

    # data args
    parser.add_argument('--outdir', type=str, required=True,
                        help='Output folder in which the tars should be downloaded')
    parser.add_argument('--data-type', type=str, required=True,
                        choices=['compat10', 'compat50', 'raw_models'],
                        help='Data type to download. Use "compat10" or "compat50" to download 10 or 50 rendered compositions,'
                             ' or "raw_models" for untextured 3D CAD models.')

    args = parser.parse_args(argv)

    # Printing input arguments
    print("Input arguments:")
    print(args)
    print()

    return args


def download(args):
    # Creating output directory
    out_dir = os.path.join(args.outdir, args.data_type)
    if not os.path.exists(out_dir):
        print("Created output path: [%s]" % args.outdir)
        os.makedirs(out_dir)

    if args.data_type == 'raw_models':
        print("[3DCoMPaT] Downloading raw models...\n")
        model_file = "all_models.zip"
        model_url = os.path.join(ROOT_BUCKET_URL, "GLB/", model_file)
        new_path = os.path.join(out_dir, model_file)

        os.system("wget -O %s %s " % (new_path, model_url))
        print("Done. \n")

    elif args.data_type.startswith('compat'):
        n_comp = int(args.data_type[-2:])
        print("[3DCoMPaT] Downloading CoMPaT%d..." % n_comp)

        for split in ["train", "val"]:
            print("[3DCoMPaT] Downloading %s set..." % split)
            for k in range(n_comp):
                tar_file = "%s/%s_%04d.tar" % (split, split, k)
                model_url = os.path.join(ROOT_BUCKET_URL, "WDS/", tar_file)
                new_path = os.path.join(out_dir, tar_file)

                if not os.path.exists(os.path.dirname(new_path)):
                    os.makedirs(os.path.dirname(new_path))

                os.system("wget -O %s %s" % (new_path, model_url))
                print()
            print("Done. \n")

    real_out = os.path.realpath(out_dir)
    print("[3DCoMPaT] Succesfully downloaded %s in: [%s]." % (args.data_type, real_out))

def main(argv=None):
    args = parse_args(argv)
    download(args)


if __name__ == "__main__":
    main()
