"""
Downloading the 3DCoMPaT dataset.
"""


import argparse
import json
import tqdm
import os


ROOT_BUCKET_URL = "https://3dcompat-dataset.s3-us-west-1.amazonaws.com/"


def parse_args(argv):
    """
    Parsing input arguments.
    """

    # Arguments
    parser = argparse.ArgumentParser(description='Download the 3DCompat dataset.')

    # data args
    parser.add_argument('--outdir', type=str, required=True,
                        help='Output folder in which the zips should be downloaded')
    parser.add_argument('--data-type', type=str, required=True,
                        choices=['canonical_seg', 'canonical_views', 'random_views', 'rendered_models'],
                        help='Data type to download. One of "canonical_seg" for canonical views segmentations masks,'
                             ' "canonical_views" or "random_views" for canonical/random views, "rendered_models" for rendered 3D models.')

    args = parser.parse_args(argv)
    args.meta_file = os.path.join("./download", args.data_type + ".json")

    if not os.path.exists(args.outdir):
        print("Error: Output path: [%s] does not exist." % args.outdir)
        exit(-1)

    # Printing input arguments
    print("Input arguments:")
    print(args)
    print()

    return args


def download(args):
    meta_data = json.load(open(args.meta_file))
    out_dir = os.path.join(args.outdir, args.data_type)
    
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    for file, new_name in tqdm.tqdm(meta_data.items()):
        bucket_url = os.path.join(ROOT_BUCKET_URL, file)
        new_path = os.path.join(out_dir, new_name)
        os.system("wget -O %s %s >/dev/null 2>&1" % (new_path, bucket_url))


def main(argv=None):
    args = parse_args(argv)
    download(args)


if __name__ == "__main__":
    main()
